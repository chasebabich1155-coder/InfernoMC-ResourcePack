#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

// InfernoMC: text in exactly this orange (#FE9119, a maxed enchant on the pickaxe) becomes a
// yellow-orange-red wave that moves along the text over time. Its drop shadow is the same color at
// a quarter brightness, so that gets the wave too, darkened.
const vec3 SPECTRAL = vec3(254.0, 145.0, 25.0) / 255.0;
const vec3 SPECTRAL_SHADOW = vec3(63.0, 36.0, 6.0) / 255.0;

// And text in exactly this purple (#A21CFD, GG wave chat) becomes a moving rainbow, the same way.
const vec3 RAINBOW = vec3(162.0, 28.0, 253.0) / 255.0;
const vec3 RAINBOW_SHADOW = vec3(40.0, 7.0, 63.0) / 255.0;

vec3 rainbow(vec2 at) {
    // A full trip round the colors every 2 seconds, flowing along the text and down the lines.
    float hue = fract(GameTime * 600.0 - at.x * 0.5 + at.y * 0.75);
    vec3 rgb = clamp(abs(mod(hue * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
    // Saturation 0.65, full brightness: bright but soft, readable in chat.
    return mix(vec3(1.0), rgb, 0.65);
}

bool isColor(vec3 color, vec3 wanted, float tolerance) {
    return all(lessThan(abs(color - wanted), vec3(tolerance / 255.0)));
}

// And text in exactly this magenta (#D81CF6, a maxed Essence enchant) becomes a pink-purple wave.
const vec3 ESSENCE = vec3(216.0, 28.0, 246.0) / 255.0;
const vec3 ESSENCE_SHADOW = vec3(54.0, 7.0, 61.0) / 255.0;

/**
 * A wave through three colors (0-255) that moves along the text over time. GameTime runs 0 to 1
 * over a day (24,000 ticks): x 600 is one wave every 2 seconds. It shifts a little each line down,
 * so stacked lines (the pickaxe's enchants) flow diagonally.
 */
vec3 wave3(vec2 at, vec3 first, vec3 middle, vec3 last) {
    float wave = 0.5 + 0.5 * sin(6.2831853 * (GameTime * 600.0 - at.x * 2.0 + at.y * 3.0));
    vec3 color = wave < 0.5 ? mix(first, middle, wave * 2.0) : mix(middle, last, wave * 2.0 - 1.0);
    return color / 255.0;
}

vec3 spectral(vec2 at) {
    return wave3(at, vec3(255.0, 225.0, 77.0), vec3(255.0, 140.0, 0.0), vec3(255.0, 40.0, 26.0));
}

// InfernoMC Farming: text in exactly this red (#E8141E, a fully mastered hoe enchant) becomes a
// red and black wave, the same way.
const vec3 MASTERED = vec3(232.0, 20.0, 30.0) / 255.0;
const vec3 MASTERED_SHADOW = vec3(58.0, 5.0, 7.0) / 255.0;

vec3 mastered(vec2 at) {
    return wave3(at, vec3(255.0, 40.0, 40.0), vec3(40.0, 0.0, 0.0), vec3(190.0, 0.0, 0.0));
}

vec3 essence(vec2 at) {
    return wave3(at, vec3(255.0, 120.0, 210.0), vec3(205.0, 95.0, 255.0), vec3(140.0, 60.0, 230.0));
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // InfernoMC: the XP level number is drawn in a fixed lime green (#80FF20); show it orange-red
    // (#FF4A1A) instead. Nothing else is drawn in exactly that green.
    vec4 color = Color;
    if (all(lessThan(abs(Color.rgb - vec3(128.0, 255.0, 32.0) / 255.0), vec3(0.01)))) {
        color = vec4(vec3(255.0, 74.0, 26.0) / 255.0, Color.a);
    } else if (isColor(Color.rgb, SPECTRAL, 0.6)) {
        color = vec4(spectral(gl_Position.xy), Color.a);
    } else if (isColor(Color.rgb, SPECTRAL_SHADOW, 1.5)) {
        color = vec4(spectral(gl_Position.xy) * 0.25, Color.a);
    } else if (isColor(Color.rgb, RAINBOW, 0.6)) {
        color = vec4(rainbow(gl_Position.xy), Color.a);
    } else if (isColor(Color.rgb, RAINBOW_SHADOW, 1.5)) {
        color = vec4(rainbow(gl_Position.xy) * 0.25, Color.a);
    } else if (isColor(Color.rgb, MASTERED, 0.6)) {
        color = vec4(mastered(gl_Position.xy), Color.a);
    } else if (isColor(Color.rgb, MASTERED_SHADOW, 1.5)) {
        color = vec4(mastered(gl_Position.xy) * 0.25, Color.a);
    } else if (isColor(Color.rgb, ESSENCE, 0.6)) {
        color = vec4(essence(gl_Position.xy), Color.a);
    } else if (isColor(Color.rgb, ESSENCE_SHADOW, 1.5)) {
        color = vec4(essence(gl_Position.xy) * 0.25, Color.a);
    }

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = color;
#endif
    texCoord0 = UV0;
}
